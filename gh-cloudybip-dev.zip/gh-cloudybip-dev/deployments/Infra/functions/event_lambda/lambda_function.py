import json
import logging
import boto3

def lambda_handler(event, context):
    regionname =  os.environ['AWS_REGION']
    client = boto3.client("datasync", region_name=regionname)
    # TODO implement
    print(event)
    print('context')
    print(context)
    

    response = client.list_tasks()
    #print("tasks : "+str(response))
    tasks = response["Tasks"]
    for task in tasks:
        print("Task: "+task['Name']+" Status: "+task['Status'])
        taskresponse = client.describe_task(TaskArn=task['TaskArn'])
        #print("location: "+taskresponse['SourceLocationArn'])
        if 'Schedule' in taskresponse:
            print("schedule status"+str(taskresponse['Schedule']))
            try:
                response = client.delete_task(TaskArn=task['TaskArn'])
            except:
                print("Something went wrong")
            finally:
                print("Finally done")
    
